package com.lpucapstone.fitnessmania.ui;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.github.silvestrpredko.dotprogressbar.DotProgressBar;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.lpucapstone.fitnessmania.utils.ProjectUtils;
import com.lpucapstone.fitnessmania.R;
import com.lpucapstone.fitnessmania.model.User;

import java.util.concurrent.TimeUnit;


public class LoginActivity extends AppCompatActivity {

    private EditText contactNumber;
    private RelativeLayout progress,content;
    private String enteredOTP,sentOTP,phoneNumber;
    private TextView errorText;
    private FirebaseAuth firebaseAuth;
    private DatabaseReference databaseReference;
    private FirebaseUser user;
    private Dialog getOTP;
    private DotProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        contactNumber = findViewById(R.id.editTxtNumber);
        progress = findViewById(R.id.progress_layout);
        content = findViewById(R.id.content_layout);
        errorText = findViewById(R.id.error_text);
        firebaseAuth = FirebaseAuth.getInstance();
    }

    public void sendVarificationCode(View view) {
        if (validateForm()) {
            phoneNumber = "+91" + contactNumber.getText().toString().trim();

            AlertDialog.Builder dialogue = new AlertDialog.Builder(this,R.style.AlertDialogTheme);
            dialogue.setTitle("Check Mobile Number");
            dialogue.setMessage("Please check if the mobile Number: " + phoneNumber + " is correct or you would like to Edit it?");
            dialogue.setPositiveButton("Continue", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                   startVerificationProcess();
                }
            });
            dialogue.setNegativeButton("Edit", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                }
            });
            dialogue.show();
        }
    }

    private void startVerificationProcess() {
        content.setVisibility(View.INVISIBLE);
        progress.setVisibility(View.VISIBLE);
        PhoneAuthProvider.getInstance().verifyPhoneNumber(
                phoneNumber,
                30,
                TimeUnit.SECONDS,
                this,
                mCallbacks);
    }

    PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
        @Override
        public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) { }

        @Override
        public void onVerificationFailed(@NonNull FirebaseException e) {
            e.printStackTrace();
            //error
            Log.d("Sonu", "onVerificationFailed");
        }

        @Override
        public void onCodeSent(@NonNull String codeSentFromFirebase, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {
            super.onCodeSent(codeSentFromFirebase, forceResendingToken);
            sentOTP = codeSentFromFirebase;
            progress.setVisibility(View.GONE);
            content.setVisibility(View.VISIBLE);
            if(sentOTP == null){
                errorText.setVisibility(View.VISIBLE);
                errorText.setText("Some Error Occured, Try Again!");
            }
            else
            {
                openDialogForOTP();
            }
        }
    };

    private void openDialogForOTP() {
        getOTP =new Dialog(this);
        View dialogView =getLayoutInflater().inflate(R.layout.otp_dialog_layout,null);
        progressBar = dialogView.findViewById(R.id.progressbar);
        getOTP.setTitle("Verify OTP");
        getOTP.setContentView(dialogView);
        final EditText otp = dialogView.findViewById(R.id.otp_number);
        final Button verifyBtn = dialogView.findViewById(R.id.btn_verify);
        getOTP.setCancelable(false);
        getOTP.show();
        verifyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                verifyBtn.setVisibility(View.INVISIBLE);
                progressBar.setVisibility(View.VISIBLE);
                if(TextUtils.isEmpty(otp.getText())){
                    otp.setError("Required");
                    verifyBtn.setVisibility(View.VISIBLE);
                    progressBar.setVisibility(View.INVISIBLE);
                }
                else{
                    enteredOTP = otp.getText().toString().trim();
                    verifyOTP();
                }
            }
        });
    }

    private void verifyOTP() {
        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(sentOTP,enteredOTP);
        signInWithPhoneAuthCredential(credential);
    }

    private void signInWithPhoneAuthCredential(PhoneAuthCredential credential) {
        firebaseAuth.signInWithCredential(credential).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    login();
                }else {
                    Toast.makeText(getApplicationContext(), "Unable to Verify", Toast.LENGTH_LONG).show();
                    if (task.getException() instanceof FirebaseAuthInvalidCredentialsException) {
                        errorText.setVisibility(View.VISIBLE);
                        errorText.setText("Unable to Verify, Please try Again!");
                    }
                    getOTP.dismiss();
                }

            }
        });
    }

    private void login() {
        user = FirebaseAuth.getInstance().getCurrentUser();
        databaseReference = FirebaseDatabase.getInstance().getReference("Users");
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                boolean exist = false;
                for(DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    User localUser = snapshot.getValue(User.class);
                    if (user!=null && localUser.getNumber().contains(phoneNumber) && localUser.getName()!=null && localUser.getAge()!=null) {
                        exist = true;
                        Log.d("sonu","not first time, should go to main Activity");
                        Intent intent = new Intent(LoginActivity.this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK| Intent.FLAG_ACTIVITY_NEW_TASK);
                        getOTP.dismiss();
                        startActivity(intent);
                        finish();
                    }
                    else if(user!=null && localUser.getNumber().contains(phoneNumber)){
                        Intent intent = new Intent(LoginActivity.this, AddUserActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        getOTP.dismiss();
                        startActivity(intent);
                        finish();
                    }
                }
                if(exist==false){
                    Log.d("sonu","first time, should go to Add User Activity");
                    Intent intent = new Intent(LoginActivity.this, AddUserActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    getOTP.dismiss();
                    startActivity(intent);
                    finish();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) { }
        });

    }

    private boolean validateForm() {
        boolean state = true;
        String s1 = contactNumber.getText().toString().trim();
        if (TextUtils.isEmpty(s1)) {
            contactNumber.setError("Required");
            state = false;
        }
        if (s1.length() != 10) {
            contactNumber.setError("Invalid Number");
            state = false;
        }
        if(!ProjectUtils.validNumber(s1)){
            contactNumber.setError("Invalid Number");
            state = false;
        }
        return state;
    }

    @Override
    protected void onStart() {
        super.onStart();
        user = firebaseAuth.getCurrentUser();
        if (user != null) {
            Intent intent = new Intent(LoginActivity.this,MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            finish();
        }
    }
}
