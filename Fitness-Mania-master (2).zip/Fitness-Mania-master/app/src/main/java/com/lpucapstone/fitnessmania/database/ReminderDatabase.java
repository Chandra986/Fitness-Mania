package com.lpucapstone.fitnessmania.database;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.lpucapstone.fitnessmania.model.ReminderVo;

@Database(entities = ReminderVo.class,version = 1,exportSchema = false)
public abstract class ReminderDatabase extends RoomDatabase {

    public abstract ReminderDao reminderDao();
    private static volatile ReminderDatabase reminderDatabaseInstance;

    public static ReminderDatabase getNotesDatabaseInstance(final Context context){
        if(reminderDatabaseInstance==null){
            synchronized (ReminderDatabase.class) {
                if(reminderDatabaseInstance==null){
                    reminderDatabaseInstance = Room.databaseBuilder(context.getApplicationContext(),ReminderDatabase.class,"Reminder_Database").build();
                }
            }
        }
        return  reminderDatabaseInstance;
    }
}
