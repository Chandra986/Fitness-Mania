package com.lpucapstone.fitnessmania.fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.lpucapstone.fitnessmania.utils.ProjectUtils;
import com.lpucapstone.fitnessmania.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class CalculateFragment extends Fragment {

    private EditText weight, height, age, gender;
    private Button calculate;
    private TextView result;
    private double bmr;
    private Spinner activityLevel;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_calculate, container, false);
        weight = view.findViewById(R.id.edittext_weight);
        height = view.findViewById(R.id.edittext_height);
        age = view.findViewById(R.id.edittext_age);
        gender = view.findViewById(R.id.edittext_gender);
        calculate = view.findViewById(R.id.calculate);
        result = view.findViewById(R.id.result);
        activityLevel = view.findViewById(R.id.activity_level);
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(this.getContext(),android.R.layout.simple_spinner_dropdown_item, ProjectUtils.getActivityFactor());
        activityLevel.setAdapter(arrayAdapter);
        activityLevel.setSelection(0);

        calculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showresults();
            }
        });
        return view;
    }

    private void showresults() {
        if (validDetails()) {
            if (gender.getText().toString().toLowerCase().contains("m")) {
                bmr = (10 * Float.parseFloat(weight.getText().toString().trim())) + (6.25 * Float.parseFloat(height.getText().toString())) -
                        (5 * Float.parseFloat(age.getText().toString())) + 5;
            } else if (gender.getText().toString().toLowerCase().contains("f")) {
                bmr = (10 * Float.parseFloat(weight.getText().toString().trim())) + (6.25 * Float.parseFloat(height.getText().toString())) -
                        (5 * Float.parseFloat(age.getText().toString())) - 161;
            }
            if(activityLevel.getSelectedItemPosition()==1)bmr = bmr*1.25;
            else if(activityLevel.getSelectedItemPosition()==2)bmr = bmr*1.45;
            else if(activityLevel.getSelectedItemPosition()==3)bmr = bmr*1.63;
            else if(activityLevel.getSelectedItemPosition()==4)bmr = bmr*1.81;
            else if(activityLevel.getSelectedItemPosition()==5)bmr = bmr*1.99;
            result.setText("You need "+ bmr +" calories  per day to maintain your weight");
        }
    }

    private boolean validDetails() {
        boolean valid = true;
        if (TextUtils.isEmpty(weight.getText())) {
            valid = false;
            weight.setError("Required");
        }
        if (TextUtils.isEmpty(height.getText())) {
            valid = false;
            height.setError("Required");
        }
        if (TextUtils.isEmpty(age.getText())) {
            valid = false;
            age.setError("Required");
        }
        if (TextUtils.isEmpty(gender.getText())) {
            valid = false;
            gender.setError("Required");
        }
        if (!gender.getText().toString().toLowerCase().contains("m") && !gender.getText().toString().toLowerCase().contains("f")) {
            valid = false;
            gender.setError("Invalid");
        }
        if(activityLevel.getSelectedItemPosition()==0){
            Toast.makeText(this.getContext(),"Please Select your Activity Level",Toast.LENGTH_LONG).show();
            valid = false;
        }
        return valid;
    }
}
