package com.lpucapstone.fitnessmania.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.lpucapstone.fitnessmania.subscreens.ExerciseDetailActivity;
import com.lpucapstone.fitnessmania.R;

public class ExerciseGuide extends AppCompatActivity{

    private Toolbar toolbar;
    private Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercise_guide);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Personal Workout Guide");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        intent = new Intent(ExerciseGuide.this, ExerciseDetailActivity.class);
    }

    public void absClicked(View view) {
        intent.putExtra("exercise","abs");
        startActivity(intent);
    }

    public void backClicked(View view) {
        intent.putExtra("exercise","back");
        startActivity(intent);
    }

    public void bicepsClicked(View view) {
        intent.putExtra("exercise","biceps");
        startActivity(intent);
    }

    public void calfClicked(View view) {
        intent.putExtra("exercise","calf");
        startActivity(intent);
    }

    public void chestClicked(View view) {
        intent.putExtra("exercise","chest");
        startActivity(intent);
    }

    public void forearmClicked(View view) {
        intent.putExtra("exercise","forearm");
        startActivity(intent);
    }

    public void legClicked(View view) {
        intent.putExtra("exercise","leg");
        startActivity(intent);
    }

    public void shoulderClicked(View view) {
        intent.putExtra("exercise","shoulder");
        startActivity(intent);
    }

    public void tricepsClicked(View view) {
        intent.putExtra("exercise","triceps");
        startActivity(intent);
    }
}
