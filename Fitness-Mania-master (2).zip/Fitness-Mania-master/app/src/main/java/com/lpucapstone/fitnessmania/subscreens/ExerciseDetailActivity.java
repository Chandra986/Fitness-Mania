package com.lpucapstone.fitnessmania.subscreens;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.widget.ImageView;

import com.lpucapstone.fitnessmania.R;

public class ExerciseDetailActivity extends AppCompatActivity {

    private Toolbar toolbar;
    private ImageView image1,image2;
    private String exercise_name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercise_detail);
        toolbar = findViewById(R.id.toolbar);
        image1 = findViewById(R.id.exercise_image1);
        image2 = findViewById(R.id.exercise_image2);
        setSupportActionBar(toolbar);
        exercise_name = getIntent().getStringExtra("exercise");
        getSupportActionBar().setTitle(exercise_name.toUpperCase());
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setImages();
    }

    private void setImages() {
        switch (exercise_name){
            case "abs":
                image1.setImageResource(R.drawable.abs1);
                image2.setImageResource(R.drawable.abs2);
                break;
            case "back":
                image1.setImageResource(R.drawable.back11);
                image2.setImageResource(R.drawable.back2);
                break;
            case "biceps":
                image1.setImageResource(R.drawable.biceps1);
                image2.setImageResource(R.drawable.biceps2);
                break;
            case "triceps":
                image1.setImageResource(R.drawable.triceps1);
                image2.setImageResource(R.drawable.triceps2);
                break;
            case "leg":
                image1.setImageResource(R.drawable.leg1);
                image2.setImageResource(R.drawable.leg2);
                break;
            case "calf":
                image1.setImageResource(R.drawable.calf1);
                image2.setImageResource(R.drawable.calf2);
                break;
            case "shoulder":
                image1.setImageResource(R.drawable.shoulder1);
                image2.setImageResource(R.drawable.shoulder2);
                break;
            case "chest":
                image1.setImageResource(R.drawable.chest1);
                image2.setImageResource(R.drawable.chest2);
                break;
            case "forearm":
                image1.setImageResource(R.drawable.forearm1);
                image2.setImageResource(R.drawable.forearm2);
                break;
        }
    }
}
