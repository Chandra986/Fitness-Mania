package com.lpucapstone.fitnessmania.database;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.lpucapstone.fitnessmania.model.ReminderVo;

import java.util.List;

@Dao
public interface ReminderDao {

    @Insert
    void addReminder(ReminderVo reminder);

    @Query("Select * from Reminders")
    LiveData<List<ReminderVo>> getListOfReminders();

    @Query("Select * from Reminders where Row_Id=:rowID")
    LiveData<ReminderVo> getReminder(int rowID);

    @Update(onConflict = OnConflictStrategy.REPLACE)
    void updateMultipleReminders(List<ReminderVo> reminders);

    @Update(onConflict = OnConflictStrategy.REPLACE)
    void updateReminder(ReminderVo reminder);

    @Query("UPDATE Reminders SET Reminder_status = :status WHERE Reminder_Id = :reminderId")
    int updateStatus(int reminderId, String status);

    @Delete
    void deleteReminder(ReminderVo reminder);
}
