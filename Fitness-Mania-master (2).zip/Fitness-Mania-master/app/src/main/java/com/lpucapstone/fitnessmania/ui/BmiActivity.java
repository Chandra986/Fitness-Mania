package com.lpucapstone.fitnessmania.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.lpucapstone.fitnessmania.R;

import java.util.Locale;

import pl.pawelkleczkowski.customgauge.CustomGauge;

public class BmiActivity extends AppCompatActivity {

    private CustomGauge meter;
    private EditText weight,height;
    private TextView value,description;
    private Toolbar toolbar;
    private Float bmi;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bmi);
        meter = findViewById(R.id.bmi_meter);
        weight = findViewById(R.id.edittxt_weight);
        height = findViewById(R.id.edittxt_height);
        value = findViewById(R.id.bmi_number);
        description = findViewById(R.id.bmi_description);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Calculate Your BMI");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    public void calClicked(View view) {
        if(validateValues()){
            float w = Float.parseFloat(weight.getText().toString().trim());
            float h = Float.parseFloat(height.getText().toString().trim());
            h = (h/100);
            h=h*h;
            bmi = w/h;
            meter.setValue(bmi.intValue());
            value.setText(String.valueOf(bmi));
            setDescription();
        }

    }

    private boolean validateValues() {
        boolean correct = true;
        if(TextUtils.isEmpty(weight.getText())){
            weight.setError("Required");
            correct = false;
        }
        if(TextUtils.isEmpty(height.getText())){
            height.setError("Required");
            correct = false;
        }
        return correct;
    }

    private void setDescription() {
        if(bmi<18.5){ description.setText("Underweight");
        value.setTextColor(Color.parseColor("#06A0CF"));}
        else if(bmi>=18.5 && bmi<24.9){ description.setText("Normal Weight");
            value.setTextColor(Color.parseColor("#03DAC5"));}
        else if(bmi>=25 && bmi<29.9){ description.setText("Overweight");
            value.setTextColor(Color.parseColor("#F6EB0B"));}
        else if(bmi>=30 && bmi<34.9){ description.setText("Obesity (class 1)");
            value.setTextColor(Color.parseColor("#F16C07"));}
        else if(bmi>=35 && bmi<39.9){ description.setText("Obesity (class 2)");
            value.setTextColor(Color.parseColor("#F16C07"));}
        else{ description.setText("Extreme Obesity");
            value.setTextColor(Color.parseColor("#DA0379"));}
    }
}
