package com.lpucapstone.fitnessmania.model;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.util.Calendar;

@Entity( tableName = "Reminders")
public class ReminderVo {

    @ColumnInfo(name = "Row_Id")
    @PrimaryKey(autoGenerate = true)
    private int rowID;
    @ColumnInfo (name = "Reminder_Id")
    private int reminderId;
    @ColumnInfo(name = "Reminder_Time")
    private long reminderTime;
    @ColumnInfo (name = "Reminder_status")
    private String reminderStatus;
    @ColumnInfo(name = "Reminder_info")
    private String reminderInfo;


    public int getRowID() {
        return rowID;
    }

    public void setRowID(int rowID) {
        this.rowID = rowID;
    }

    public long getReminderTime() {
        return reminderTime;
    }

    public void setReminderTime(long reminderTime) {
        this.reminderTime = reminderTime;
    }

    public String getReminderStatus() {
        return reminderStatus;
    }

    public void setReminderStatus(String reminderStatus) {
        this.reminderStatus = reminderStatus;
    }

    public int getReminderId() {
        return reminderId;
    }

    public void setReminderId(int reminderId) {
        this.reminderId = reminderId;
    }

    public String getReminderInfo() {
        return reminderInfo;
    }

    public void setReminderInfo(String reminderInfo) {
        this.reminderInfo = reminderInfo;
    }
}
