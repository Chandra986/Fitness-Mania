package com.lpucapstone.fitnessmania.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlarmManager;
import android.app.Dialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;

import com.lpucapstone.fitnessmania.R;
import com.lpucapstone.fitnessmania.adapter.ReminderListAdapter;
import com.lpucapstone.fitnessmania.database.ReminderDao;
import com.lpucapstone.fitnessmania.database.ReminderDatabase;
import com.lpucapstone.fitnessmania.model.ReminderVo;
import com.lpucapstone.fitnessmania.receiver.ReminderBroadcastReceiver;
import com.lpucapstone.fitnessmania.utils.ProjectUtils;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import pl.pawelkleczkowski.customgauge.CustomGauge;

public class ReminderActivity extends AppCompatActivity {
    private Toolbar toolbar;
    private Bundle reminderBundle;
    private Calendar calendar;
    private EditText reminderDesc;
    private ReminderDao reminderDao;
    private ReminderDatabase reminderDatabase;
    private TextView reminderTime,waterValue;
    private RecyclerView recyclerView;
    private ReminderListAdapter adapter;
    private Dialog d;
    private CustomGauge waterMeter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reminder);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        reminderBundle = new Bundle();
        waterMeter = findViewById(R.id.water_meter);
        waterValue = findViewById(R.id.water_value);
        recyclerView = findViewById(R.id.recycler_view);
        adapter = new ReminderListAdapter(this);
        getSupportActionBar().setTitle("Water Drinking Reminder");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(adapter);
        calendar = Calendar.getInstance();
        reminderDatabase = ReminderDatabase.getNotesDatabaseInstance(getApplication());
        reminderDao = reminderDatabase.reminderDao();
        fillRecyclerView();
    }

    private void fillRecyclerView() {
        getListOfReminders().observe(this, new Observer<List<ReminderVo>>() {
            @Override
            public void onChanged(List<ReminderVo> reminderVos) {
                adapter.setReminderlist(reminderVos);
                updateMeterValue(reminderVos);
            }
        });
    }

    private void updateMeterValue(List<ReminderVo> reminderVos) {
        int doneCount = 0;
        int meterValue = 0;
        for(int i=0;i<reminderVos.size();i++){
            if(reminderVos.get(i).getReminderStatus().equals("done")){
                doneCount++;
                meterValue = meterValue+Integer.parseInt(reminderVos.get(i).getReminderInfo());
            }
        }
        waterMeter.setValue(meterValue);
        waterValue.setText(waterMeter.getValue()+" ml");

        if(reminderVos.size()>1 && doneCount == reminderVos.size()){
            for(int i=0;i<reminderVos.size();i++){
                reminderVos.get(i).setReminderStatus("pending");
                Calendar calendar1 = ProjectUtils.toCalendar(reminderVos.get(i).getReminderTime());
                calendar1.add(Calendar.DATE,1);
                reminderVos.get(i).setReminderTime(ProjectUtils.fromCalendar(calendar1));
            }
            new UpdateMultipleRemindersAsyncTask(reminderDao).execute(reminderVos);
        }
    }

    public LiveData<List<ReminderVo>> getListOfReminders() {
        LiveData<List<ReminderVo>> listOfReminders =reminderDao.getListOfReminders() ;
        return listOfReminders;
    }

    public void addClicked(View view) {
        d = new Dialog(this);
        View view1 = getLayoutInflater().inflate(R.layout.add_reminder_dialog, null);
        d.setContentView(view1);
        d.setCancelable(true);
        reminderTime = view1.findViewById(R.id.reminder_time);
        Button save = view1.findViewById(R.id.add_btn);
        reminderDesc = view1.findViewById(R.id.reminder_description);
        d.show();

        reminderTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setTime(reminderTime);
            }
        });

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validateDetails()) {
                    d.dismiss();
                    int reminderId = System.identityHashCode(reminderBundle);
                    int hour = reminderBundle.getInt("hour");
                    int minute = reminderBundle.getInt("min");
                    if (reminderBundle.getString("AM_PM").equals("PM")) {
                        hour = hour + 12;
                    }
                    int day = reminderBundle.getInt("day");
                    int month = reminderBundle.getInt("month");
                    int year = reminderBundle.getInt("year");
                    Calendar calendar_alarm = Calendar.getInstance();
                    calendar_alarm.set(year, month, day, hour, minute, 0);
                    setReminder(calendar_alarm, reminderId);
                }
            }
        });
    }

    private boolean validateDetails() {
        boolean valid = true;
        if (TextUtils.isEmpty(reminderTime.getText())) {
            valid = false;
            reminderTime.setError("Required");
        }
        if (TextUtils.isEmpty(reminderDesc.getText())) {
            valid = false;
            reminderDesc.setError("Required");
        }
        return valid;
    }

    private void setReminder(Calendar calendar_alarm, int reminderId) {
        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        Intent intent = new Intent(getApplicationContext(), ReminderBroadcastReceiver.class);
        Bundle notificationBundle = new Bundle();
        notificationBundle.putString("title", "Water Drinking Reminder");
        notificationBundle.putInt("reminderID", reminderId);
        notificationBundle.putString("text","You need to drink "+ reminderDesc.getText().toString().trim()+" ml water");
        intent.putExtras(notificationBundle);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(getApplicationContext(), reminderId, intent, 0);
        assert alarmManager != null;
        alarmManager.set(AlarmManager.RTC_WAKEUP, calendar_alarm.getTimeInMillis(), pendingIntent);
        saveReminderInDatabase(reminderId, calendar_alarm);
    }

    private void saveReminderInDatabase(int reminderId, Calendar reminderTime) {
        ReminderVo reminder = new ReminderVo();
        reminder.setReminderId(reminderId);
        reminder.setReminderInfo(reminderDesc.getText().toString().trim());
        reminder.setReminderStatus("pending");
        reminder.setReminderTime(ProjectUtils.fromCalendar(reminderTime));
        new AddReminderAsyncTask(reminderDao).execute(reminder);
    }

    private void setTime(final TextView reminderTime) {
        TimePickerDialog dialog = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker timePicker, int hour, int minute) {
                if (hour > 12) hour = hour - 12;
                reminderBundle.putInt("hour", hour);
                reminderBundle.putInt("min", minute);
                reminderBundle.putString("AM_PM", (timePicker.getCurrentHour() > 12 ? "PM" : "AM"));
                String reminderTim = "" + hour + ":" + minute + " " + (timePicker.getCurrentHour() > 12 ? "PM" : "AM");
                reminderTime.setText(reminderTim);
            }
        }, calendar.get(Calendar.HOUR), calendar.get(Calendar.MINUTE), false);
        dialog.show();
        Calendar date = Calendar.getInstance();
        reminderBundle.putInt("day", date.get(Calendar.DATE));
        reminderBundle.putInt("month", date.get(Calendar.MONTH));
        reminderBundle.putInt("year", date.get(Calendar.YEAR));
    }

    private class AddReminderAsyncTask extends AsyncTask<ReminderVo, Void, Void> {

        ReminderDao mReminderDao;

        AddReminderAsyncTask(ReminderDao reminderDao) {
            mReminderDao = reminderDao;
        }

        @Override
        protected Void doInBackground(ReminderVo... reminderVos) {
            mReminderDao.addReminder(reminderVos[0]);
            return null;
        }
    }

    private class UpdateMultipleRemindersAsyncTask  extends AsyncTask<List<ReminderVo>,Void,Void>{
        ReminderDao reminderDao;

        UpdateMultipleRemindersAsyncTask(ReminderDao reminderDao) {
            this.reminderDao = reminderDao;
        }

        @Override
        protected Void doInBackground(List<ReminderVo>... lists) {
            reminderDao.updateMultipleReminders(lists[0]);
            return null;
        }
    }
}
