package com.lpucapstone.fitnessmania.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.lpucapstone.fitnessmania.R;

public class DietplanActivity extends AppCompatActivity {

    private Toolbar toolbar;
    private TextView breakfast,mmsnack,lunch,masnack,dinner,desert,day;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dietplan);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("5 Days Diet Plan");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        breakfast = findViewById(R.id.breakfast);
        mmsnack = findViewById(R.id.mmsnack);
        lunch = findViewById(R.id.lunch);
        masnack = findViewById(R.id.masnack);
        dinner = findViewById(R.id.dinner);
        desert = findViewById(R.id.desert);
        day = findViewById(R.id.day);

    }

    public void day1Clicked(View view) {
        day.setText("Day 1 ");
        breakfast.setText(R.string.day_1_breakfast);
        mmsnack.setText(R.string.day_1_mmsnack);
        lunch.setText(R.string.day_1_lunch);
        masnack.setText(R.string.day_1_masnack);
        dinner.setText(R.string.day_1_dinner);
        desert.setText(R.string.day_1_desert);

    }

    public void day2Clicked(View view) {
        day.setText("Day 2 ");
        breakfast.setText(R.string.day_2_breakfast);
        mmsnack.setText(R.string.day_2_mmsnack);
        lunch.setText(R.string.day_2_lunch);
        masnack.setText(R.string.day_2_masnack);
        dinner.setText(R.string.day_2_dinner);
        desert.setText(R.string.day_2_desert);
    }

    public void day3Clicked(View view) {
        day.setText("Day 3 ");
        breakfast.setText(R.string.day_3_breakfast);
        mmsnack.setText(R.string.day_3_mmsnack);
        lunch.setText(R.string.day_3_lunch);
        masnack.setText(R.string.day_3_masnack);
        dinner.setText(R.string.day_3_dinner);
        desert.setText(R.string.day_3_desert);
    }

    public void day4Clicked(View view) {
        day.setText("Day 4 ");
        breakfast.setText(R.string.day_4_breakfast);
        mmsnack.setText(R.string.day_4_mmsnack);
        lunch.setText(R.string.day_4_lunch);
        masnack.setText(R.string.day_4_masnack);
        dinner.setText(R.string.day_4_dinner);
        desert.setText(R.string.day_4_desert);
    }

    public void day5Clicked(View view) {
        day.setText("Day 5 ");
        breakfast.setText(R.string.day_5_breakfast);
        mmsnack.setText(R.string.day_5_mmsnack);
        lunch.setText(R.string.day_5_lunch);
        masnack.setText(R.string.day_5_masnack);
        dinner.setText(R.string.day_5_dinner);
        desert.setText(R.string.day_5_desert);
    }
}
