package com.lpucapstone.fitnessmania.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Dictionary;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ProjectUtils {



    public static boolean validNumber(String number) {
        boolean valid = true;
        String numberPattern = "[0-9]{10}";

        if (!number.matches(numberPattern)) valid = false;

        return valid;
    }

    public static ArrayList<String> getFoodDetails(){
        ArrayList<String> temp = new ArrayList<>();
        temp.add("Apple\t1 small (4 oz.)\t = 80 calories");
        temp.add("Banana\t1 medium (6 oz.)\t = 101 calories");
        temp.add("Grape\teach\t = 2 calories");
        temp.add("Mango\t1 (8 oz.)\t = 135 calories");
        temp.add("Orange\t1 (4 oz.)\t = 71 calories");
        temp.add("Pear\t1 (5 oz.)\t = 100 calories");
        temp.add("Peach\t1 (6 oz.)\t = 38 calories");
        temp.add("Pineapple\t1 cup\t = 80 calories");
        temp.add("Strawberry\t1 cup\t  = 53 calories");
        temp.add("Watermelon\t1 cup\t = 45 calories");
        temp.add("Asparagus\t1 cup, boiled\t = 36 calories");
        temp.add("Bean curd\t4 oz.\t = 81 calories");
        temp.add("Broccoli\t1 cup\t = 40 calories");
        temp.add("Carrots\t1 cup\t = 45 calories");
        temp.add("Cucumber\teach\t = 30 calories");
        temp.add("Eggplant\t1 cup, boiled\t = 38 calories");
        temp.add("Lettuce\t1 cup\t = 7 calories");
        temp.add("Tomato\t1 cup\t = 29 calories");
        temp.add("Chicken, cooked\t1 slice (2 oz.)\t = 95 calories");
        temp.add("Egg large = 79 calories");
        temp.add("Fish, Catfish, cooked\t2 oz.\t = 80 calories");
        temp.add("Shrimp, cooked\t2 oz.\t = 70 calories");
        temp.add("Bread, regular\t1 slice (1 oz.)\t = 75 calories");
        temp.add("Butter\t1 table spoon\t = 102 calories");
        temp.add("Caesar salad\t1 serving (3 cups)\t = 360 calories");
        temp.add("Cheeseburger\t1 (McDonald Medium)\t = 360 calories");
        temp.add("Chocolate\t1 oz.\t = 150 calories");
        temp.add("Corn\t1 cup, cooked\t = 140 calories");
        temp.add("Hamburger\t1 (McDonald Medium)\t = 280 calories");
        temp.add("Pizza\t1 slice\t = 180 calories");
        temp.add("Potato (uncooked)\t1 (6 oz.)\t = 120 calories");
        temp.add("Sandwich\t1 (6\" Subway)\t = 310 calories");
        temp.add("Rice, cooked\t1 cup\t = 225 calories");
        temp.add("Beer, regular\t1 can or bottle\t = 150 calories");
        temp.add("Coca-Cola Classic\t1 cup\t = 97 calories");
        temp.add("Diet Coke\t1 cup\t = 3 calories");
        temp.add("Milk, low-fat (1%)\t1 cup\t = 104 calories");
        temp.add("Milk, low-fat (2%)\t1 cup\t = 121 calories");
        temp.add("Milk, whole\t1 cup\t = 150 calories");
        temp.add("Orange Juice / Apple Cider\t1 cup\t = 115 calories");
        temp.add("Yogurt, low-fat\t1 cup\t = 200 calories");
        temp.add("Yogurt, non-fat\t1 cup\t = 150 calories");
        return temp;
    }

    public static ArrayList<String> getActivityFactor(){
        ArrayList<String> temp = new ArrayList<>();
        temp.add("Select Activity Level");
        temp.add("Sedentary(Little Exercise)");
        temp.add("Light Exercise(1-3x/week)");
        temp.add("Moderate Exercise(3-5x/week)");
        temp.add("Hard Exercise(6-7x/week)");
        temp.add("Very Hard(2x/day)");
        return temp;
    }

    public static Calendar toCalendar(long l) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(l);
        return c;
    }

    public static long fromCalendar(Calendar c){
        return c == null ? null : c.getTimeInMillis();
    }


}
