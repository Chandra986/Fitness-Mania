package com.lpucapstone.fitnessmania.ui;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.lpucapstone.fitnessmania.R;
import com.lpucapstone.fitnessmania.model.User;

import de.hdodenhof.circleimageview.CircleImageView;

public class MainActivity extends AppCompatActivity {
    private Toolbar toolbar;
    private CircleImageView userImage;
    private TextView userName;
    private FirebaseAuth firebaseAuth;
    private FirebaseUser user;
    private DatabaseReference databaseReference;
    private StorageReference storageReference;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("");
        userImage = findViewById(R.id.user_image);
        userName = findViewById(R.id.user_name);
        firebaseAuth = FirebaseAuth.getInstance();
        user = firebaseAuth.getCurrentUser();
        databaseReference = FirebaseDatabase.getInstance().getReference("Users").child(user.getUid());
        storageReference = FirebaseStorage.getInstance().getReference("uploads");
        setProfile();

    }

    private void setProfile() {
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                User userLocal = dataSnapshot.getValue(User.class);
                if(userLocal!=null){
                    if(userLocal.getImageLink()!=null && !userLocal.getImageLink().equals("default"))
                        Glide.with(getApplicationContext()).load(userLocal.getImageLink()).into(userImage);
                    if(userLocal.getName().contains(" "))
                        userName.setText("Hi! "+userLocal.getName().substring(0,userLocal.getName().indexOf(" ")));
                    else
                        userName.setText("Hi! " +userLocal.getName());
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) { }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_page_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        AlertDialog.Builder confirmDialog = new AlertDialog.Builder(this, R.style.AlertDialogTheme);
        confirmDialog.setTitle("Confirm");
        confirmDialog.setMessage("Do you want to logout?");
        confirmDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                FirebaseAuth.getInstance().signOut();
                startActivity(new Intent(MainActivity.this, LoginActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                finish();
            }
        });
        confirmDialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        confirmDialog.show();
        return true;
    }

    public void bmiClicked(View view) {
        startActivity(new Intent(MainActivity.this, BmiActivity.class));
    }

    public void dietClicked(View view) {
        startActivity(new Intent(MainActivity.this, DietplanActivity.class));
    }

    public void waterClicked(View view) {
        startActivity(new Intent(MainActivity.this, ReminderActivity.class));
    }

    public void guideClicked(View view) {
        startActivity(new Intent(MainActivity.this, ExerciseGuide.class));
    }

    public void calorieClicked(View view) {
        startActivity(new Intent(MainActivity.this, CalorieCalculatorActivity.class));
    }
}
