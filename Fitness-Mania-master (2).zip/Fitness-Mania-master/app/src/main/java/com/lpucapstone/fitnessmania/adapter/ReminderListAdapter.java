package com.lpucapstone.fitnessmania.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.lpucapstone.fitnessmania.subscreens.ReminderDetailActivity;
import com.lpucapstone.fitnessmania.utils.ProjectUtils;
import com.lpucapstone.fitnessmania.R;
import com.lpucapstone.fitnessmania.model.ReminderVo;

import java.util.Calendar;
import java.util.List;

public class ReminderListAdapter extends RecyclerView.Adapter<ReminderListAdapter.MyViewHolder> {

    private List<ReminderVo> listOfReminders;
    private Context context;
    private LayoutInflater inflater;

    public ReminderListAdapter(Context context){
        this.context = context;
        inflater = LayoutInflater.from(context);
    }

    public void setReminderlist(List<ReminderVo> reminderVos) {
        listOfReminders = reminderVos;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemview = LayoutInflater.from(context).inflate(R.layout.water_reminder_list_item,parent,false);
        ReminderListAdapter.MyViewHolder myViewHolder = new ReminderListAdapter.MyViewHolder(itemview);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        final ReminderVo reminder = listOfReminders.get(position);
        Calendar calendar = ProjectUtils.toCalendar(reminder.getReminderTime());
        String am_pm = calendar.get(Calendar.AM_PM)==0 ? "AM" :"PM";
        String time = calendar.get(Calendar.HOUR)+":"+calendar.get(Calendar.MINUTE)+" "+am_pm;
        holder.time.setText(time);
        holder.value.setText(reminder.getReminderInfo()+" ml");
        if(reminder.getReminderStatus().equals("pending")){
            holder.status.setImageResource(R.drawable.next_icon);
        }else holder.status.setImageResource(R.drawable.done_icon);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, ReminderDetailActivity.class);
                intent.putExtra("id", reminder.getRowID());
                (context).startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        if(listOfReminders!=null)
            return listOfReminders.size();
        else
            return 0;

    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView time, value;
        ImageView status;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            time = itemView.findViewById(R.id.reminder_list_item_time);
            value = itemView.findViewById(R.id.reminder_list_item_value);
            status = itemView.findViewById(R.id.status_image);
        }
    }
}
