package com.lpucapstone.fitnessmania.model;

public class User {
    private String name;
    private String imageLink;
    private String age;
    private String number;

    public User(String name, String imageLink, String age, String number) {
        this.name = name;
        this.imageLink = imageLink;
        this.age = age;
        this.number = number;
    }
    public User() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImageLink() {
        return imageLink;
    }

    public void setImageLink(String imageLink) {
        this.imageLink = imageLink;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }
}
