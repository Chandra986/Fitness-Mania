package com.lpucapstone.fitnessmania.subscreens;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.lifecycle.Observer;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;

import com.lpucapstone.fitnessmania.R;
import com.lpucapstone.fitnessmania.database.ReminderDao;
import com.lpucapstone.fitnessmania.database.ReminderDatabase;
import com.lpucapstone.fitnessmania.model.ReminderVo;
import com.lpucapstone.fitnessmania.receiver.ReminderBroadcastReceiver;
import com.lpucapstone.fitnessmania.ui.ReminderActivity;
import com.lpucapstone.fitnessmania.utils.ProjectUtils;

import java.util.Calendar;

public class ReminderDetailActivity extends AppCompatActivity {

    private Toolbar toolbar;
    private EditText reminderDesc;
    private TextView reminderTime;
    private ReminderDao reminderDao;
    private ReminderDatabase reminderDatabase;
    private Bundle reminderBundle;
    private int id,reminderId;
    private Calendar calendar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reminder_detail);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Update Reminder");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        reminderDesc = findViewById(R.id.reminder_description);
        reminderTime = findViewById(R.id.reminder_time);
        reminderDatabase = ReminderDatabase.getNotesDatabaseInstance(getApplication());
        reminderDao = reminderDatabase.reminderDao();
        id = getIntent().getIntExtra("id",-1);
        reminderBundle = new Bundle();
        calendar = Calendar.getInstance();
        showReminderDetails();

    }

    private void showReminderDetails() {
        reminderDao.getReminder(id).observe(this, new Observer<ReminderVo>() {
            @Override
            public void onChanged(ReminderVo reminderVo) {
                reminderDesc.setText(reminderVo.getReminderInfo());
                Calendar calendar1 = ProjectUtils.toCalendar(reminderVo.getReminderTime());
                String am_pm = calendar1.get(Calendar.AM_PM)==0 ? "AM" :"PM";
                String time = calendar1.get(Calendar.HOUR)+":"+calendar1.get(Calendar.MINUTE)+" "+am_pm;
                reminderId = reminderVo.getReminderId();
                reminderTime.setText(time);
            }
        });
    }

    public void saveClicked(View view) {
        if(validateDetails()){ ;
            int hour = reminderBundle.getInt("hour");
            int minute = reminderBundle.getInt("min");
            if (reminderBundle.getString("AM_PM").equals("PM")) {
                hour = hour + 12;
            }
            int day = reminderBundle.getInt("day");
            int month = reminderBundle.getInt("month");
            int year = reminderBundle.getInt("year");
            Calendar calendar_alarm = Calendar.getInstance();
            calendar_alarm.set(year, month, day, hour, minute, 0);
            setReminder(calendar_alarm);
        }
    }

    private void setReminder(Calendar calendar_alarm) {
        cancelOldReminder();
        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        Intent intent = new Intent(getApplicationContext(), ReminderBroadcastReceiver.class);
        Bundle notificationBundle = new Bundle();
        notificationBundle.putString("title", "Water Drinking Reminder");
        notificationBundle.putInt("reminderID", reminderId);
        notificationBundle.putString("text","You need to drink "+ reminderDesc.getText().toString().trim()+" ml water");
        intent.putExtras(notificationBundle);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(getApplicationContext(), reminderId, intent, 0);
        assert alarmManager != null;
        alarmManager.set(AlarmManager.RTC_WAKEUP, calendar_alarm.getTimeInMillis(), pendingIntent);
        updateReminderInDatabase(calendar_alarm);
    }

    private void updateReminderInDatabase(Calendar calendar_alarm) {
        ReminderVo reminder = new ReminderVo();
        reminder.setRowID(id);
        reminder.setReminderId(reminderId);
        reminder.setReminderInfo(reminderDesc.getText().toString().trim());
        reminder.setReminderStatus("pending");
        reminder.setReminderTime(ProjectUtils.fromCalendar(calendar_alarm));
        new UpdateReminderAsyncTask(reminderDao).execute(reminder);
        finish();
    }

    private void cancelOldReminder() {
        AlarmManager alarmManager = (AlarmManager)getSystemService(ALARM_SERVICE);
        Intent intent = new Intent(getApplicationContext(), ReminderBroadcastReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(getApplicationContext(),reminderId,intent,0);
        assert alarmManager != null;
        alarmManager.cancel(pendingIntent);
    }

    private boolean validateDetails() {
        boolean valid = true;
        if (TextUtils.isEmpty(reminderTime.getText())) {
            valid = false;
            reminderTime.setError("Required");
        }
        if (TextUtils.isEmpty(reminderDesc.getText())) {
            valid = false;
            reminderDesc.setError("Required");
        }
        return valid;
    }

    public void setTime(View view) {
        TimePickerDialog dialog = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker timePicker, int hour, int minute) {
                if (hour > 12) hour = hour - 12;
                reminderBundle.putInt("hour", hour);
                reminderBundle.putInt("min", minute);
                reminderBundle.putString("AM_PM", (timePicker.getCurrentHour() > 12 ? "PM" : "AM"));
                String reminderTim = "" + hour + ":" + minute + " " + (timePicker.getCurrentHour() > 12 ? "PM" : "AM");
                reminderTime.setText(reminderTim);
            }
        }, calendar.get(Calendar.HOUR), calendar.get(Calendar.MINUTE), false);
        dialog.show();
        Calendar date = Calendar.getInstance();
        reminderBundle.putInt("day", date.get(Calendar.DATE));
        reminderBundle.putInt("month", date.get(Calendar.MONTH));
        reminderBundle.putInt("year", date.get(Calendar.YEAR));
    }

    private class UpdateReminderAsyncTask extends AsyncTask<ReminderVo,Void,Void> {
        ReminderDao reminderDao;
        UpdateReminderAsyncTask(ReminderDao reminderDao) { this.reminderDao = reminderDao;}

        @Override
        protected Void doInBackground(ReminderVo... reminderVos) {
            reminderDao.updateReminder(reminderVos[0]);
            return null;
        }
    }
}
